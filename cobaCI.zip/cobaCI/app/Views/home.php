<div class="container">
    <div class="row">
        <div class="col">
            <h1>Hai guyss!!!</h1>
        </div>
    </div>
</div>