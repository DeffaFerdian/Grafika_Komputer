<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
    protected $mahasiswaModel;
    public function __construct()
    {
        $this->mahasiswaModel = new MahasiswaModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Mahasiswa',
            'mahasiswa' => $this->mahasiswaModel->getMahasiswa()
        ];

        echo view('layout/header');
        return view('mahasiswa/index', $data);
        echo view('layout/footer');
    }

    public function create()
    {
        $data = [
            'title' => 'Form Tambah Data Mahasiswa',
        ];

        echo view('layout/header');
        return view('mahasiswa/create', $data);
        echo view('layout/footer');
    }

    public function save()
    {
        //$slug = url_title($this->request->getVar('nim'), '-', true);
        //dd($this->request->getVar());
        $this->mahasiswaModel->save([
            'nim' => $this->request->getVar('nim'),
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'nama_belakang' => $this->request->getVar('nama_belakang'),
            'kota_asal' => $this->request->getVar('kota_asal'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'nama_orangtua' => $this->request->getVar('nama_orangtua'),
            'alamat_orangtua' => $this->request->getVar('alamat_orangtua'),
            'kode_pos' => $this->request->getVar('kode_pos'),
            'nomor_telepon' => $this->request->getVar('nomor_telepon'),
            'status' => $this->request->getVar('status'),
        ]);

        return redirect()->to('/mahasiswa');
    }


    public function delete($id)
    {
        $this->mahasiswaModel->delete($id);
        return redirect()->to('/mahasiswa');
    }

    public function edit($id)
    {
        $data = [
            'title' => 'Form Ubah Data Mahasiswa',
            'mahasiswa' => $this->mahasiswaModel->getMahasiswa($id)
        ];

        echo view('layout/header');
        return view('mahasiswa/edit', $data);
        echo view('layout/footer');
    }

    public function update($id)
    {
        $this->mahasiswaModel->save([
            'id' => $id,
            'nim' => $this->request->getVar('nim'),
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'kota_asal' => $this->request->getVar('kota_asal'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'nama_orangtua' => $this->request->getVar('nama_orangtua'),
            'alamat_orangtua' => $this->request->getVar('alamat_orangtua'),
            'kode_pos' => $this->request->getVar('kode_pos'),
            'nomor_telepon' => $this->request->getVar('nomor_telepon'),
            'status' => $this->request->getVar('status'),
        ]);

        return redirect()->to('/mahasiswa');
    }
}
