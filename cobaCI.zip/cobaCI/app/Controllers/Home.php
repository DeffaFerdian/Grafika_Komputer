<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        echo view('layout/header');
        return view('home');
        echo view('layout/footer');
    }

    public function coba()
    {
        echo 'Hai guyss!!!';
    }
}
