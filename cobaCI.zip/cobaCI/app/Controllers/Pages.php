<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        return view('home');
    }
    public function tentangku()
    {
        echo view('layout/header');
        return view('pages/tentangku');
        echo view('layout/footer');
    }
    public function galeriku()
    {
        echo view('layout/header');
        return view('pages/galeriku');
        echo view('layout/footer');
    }
}
