<?php

namespace App\Models;

use CodeIgniter\Model;

class MahasiswaModel extends Model
{
    protected $table      = 'mahasiwa';

    protected $allowedFields = ['nim', 'nama_lengkap', 'kota_asal', 'tanggal_lahir', 'nama_orangtua', 'alamat_orangtua', 'kode_pos', 'nomor_telepon', 'status'];

    public function getMahasiswa($id = false)
    {
        if ($id == false) {
            return $this->findAll();
        }

        return $this->where(['id' => $id])->first();
    }
}
