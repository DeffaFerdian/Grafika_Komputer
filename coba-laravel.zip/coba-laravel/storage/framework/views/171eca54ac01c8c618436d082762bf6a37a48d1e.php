<div class="container">
    <div class="row">
        <div class="col">
            <h1>Hai guyss!!!</h1>
        </div>
    </div>
</div><?php /**PATH C:\aplikasi\coba-laravel\resources\views/index.blade.php ENDPATH**/ ?>