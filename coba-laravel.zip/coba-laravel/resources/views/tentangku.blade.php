<div class="container">
    <div class="row">
        <div class="col">
            <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi iste corrupti placeat, ea, est voluptates id iusto necessitatibus illo dolore culpa debitis ut quibusdam nihil quo sint? Voluptatem, consequatur ullam!</h1>
        </div>
    </div>
</div>