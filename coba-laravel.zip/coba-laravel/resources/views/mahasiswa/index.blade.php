<body>
    <div class="container">
        <div class="row">
            <div class="col">
                <table class="table" style="text-align: middle;">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">NIM</th>
                            <th scope="col">Nama lengkap</th>
                            <th scope="col">Kota Asal</th>
                            <th scope="col">Tanggal Lahir</th>
                            <th scope="col">Nama Orang Tua</th>
                            <th scope="col">Alamat Orang Tua</th>
                            <th scope="col">Kode Pos</th>
                            <th scope="col">Nomor Telepon</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($mahasiswa as $mhs) : ?>
                            <tr>
                                <th scope="row"><?= $i++; ?></th>

                                <td><?= $mhs['nim']; ?></td>

                                <td><?= $mhs['nama_lengkap'] ?></td>

                                <td><?= $mhs['kota_asal'] ?></td>

                                <td><?= $mhs['tanggal_lahir'] ?></td>

                                <td><?= $mhs['nama_orangtua'] ?></td>

                                <td><?= $mhs['alamat_orangtua'] ?></td>

                                <td><?= $mhs['kode_pos'] ?></td>

                                <td><?= $mhs['nomor_telepon'] ?></td>

                                <td><?= $mhs['status'] ?></td>


                                <td>
                                    <a href="/mahasiswa/delete/<?= $mhs['id']; ?>" class="btn btn-success" role="button">Delete</a>
                                    <a href="/mahasiswa/edit/<?= $mhs['id']; ?> " class="btn btn-danger" role="button">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="/mahasiswa/create" class="btn btn-primary mb-3">Update Data</a>
            </div>
        </div>
    </div>
</body>