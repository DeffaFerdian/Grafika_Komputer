<div class="container">
    <div class="row">
        <div class="col-8">
            <h2 class="my-3">Form Update Data Mahasiswa</h2>
            <form action="/mahasiswa/update/<?= $mahasiswa['id']; ?>" method=" post">

                <?= csrf_field(); ?>
                <div class="row mb-3">
                    <label for="NIM" class="col-sm-2 col-form-label">NIM</label>
                    <div class="col-sm-5">
                        <input type="number" class="form-control" id="nim" name="nim" autofocus value="<?= $mahasiswa['nim']; ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="nama_lengkap" class="col-sm-2 col-form-label">Nama Lengkap</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= $mahasiswa['nama_lengkap']; ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="kota_asal" class="col-sm-2 col-form-label">Kota Asal</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="kota_asal" name="kota_asal" value="<?= $mahasiswa['kota_asal']; ?>">
                    </div>

                </div>
                <div class="row mb-3">
                    <label for="tanggal_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="tanggal_lahir" name="tanggal_lahir" value="<?= $mahasiswa['tanggal_lahir']; ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="nama_orangtua" class="col-sm-2 col-form-label">Nama Orangtua</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nama_orangtua" name="nama_orangtua" value="<?= $mahasiswa['nama_orangtua']; ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="alamat_orangtua" class="col-sm-2 col-form-label">Alamat Orangtua</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="alamat_orangtua" name="alamat_orangtua" value="<?= $mahasiswa['alamat_orangtua']; ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="kode_pos" class="col-sm-2 col-form-label">Kode Pos</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="kode_pos" name="kode_pos" value="<?= $mahasiswa['kode_pos']; ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="nomor_telepon" class="col-sm-2 col-form-label">Nomor Telepon</label>
                    <div class="col-sm-7">
                        <input type="text" class="form-control" id="nomor_telepon" name="nomor_telepon" value="<?= $mahasiswa['nomor_telepon']; ?>">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="cars">Status:</label>
                    <select name="status" id="status" value="<?= $mahasiswa['status']; ?>">
                        <option value="Tama">Tama</option>
                        <option value="Wreda">Wreda</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>